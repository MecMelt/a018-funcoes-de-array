const array = [55, 60, 41, 13, 1, 8, 30, 25, 99]

// #1 - Primeira forma clássica de resolver
// function mutiplicaPor3(array) {
//     const novoArray = []
//     for(let i = 0; i < array.length; i++) {
//         novoArray.push(array[i] * 3) 
//     }

//     return novoArray
// }

// #1 resolução 2 - ainda dá pra fazer com um map, mas ok
// const mutiplicaPor3 = (array) => {
//     let novoArray = []
//     for(let numero of array) {
//         novoArray.push(numero * 3)
//     }

//     return novoArray
// }

// console.log(mutiplicaPor3(array))

// function retornaPares(array) {
//     const novoArray = []
//     for(let numero of array) {
//         if(numero % 2 ===0) {
//             novoArray.push(numero)
//         }
//     }

//     return novoArray
// }

// function retornaPares() {
//     const novoArray = []
//     for(let numero of array) {
//         numero % 2 === 0 && novoArray.push(numero)
//     }
//     return novoArray
// }

// console.log(retornaPares(array))

const pokemons = [
    { nome: 'Bulbasaur', tipo: 'grama', vida: 40 },
    { nome: 'Bellsprout', tipo: 'grama', vida: 20 },
    { nome: 'Charmander', tipo: 'fogo', vida: 35 },
    { nome: 'Vulpix', tipo: 'fogo', vida: 25 },
    { nome: 'Squirtle', tipo: 'água', vida: 45 },
    { nome: 'Psyduck', tipo: 'água', vida: 25 },
  ]

  const multiplicaPor3 = array.map(function multiplica(item) {
    return item * 3
  })

  console.log(multiplicaPor3)